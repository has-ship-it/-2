package com.rashadmuslim.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

val Context.adhanDataStore by preferencesDataStore(name = "adhan_settings")

/** أسماء الصلوات الخمس بالإنجليزية (تُستخدم كمفاتيح داخلية وأسماء أعمال الإنذار). */
enum class PrayerKey { Fajr, Dhuhr, Asr, Maghrib, Isha }

data class AdhanSettings(
    val enabledPrayers: Set<PrayerKey>,
    val customSoundUri: String?,   // null = صوت الإشعار الافتراضي للنظام
    val notificationsEnabled: Boolean
)

class AdhanPreferencesRepository(private val context: Context) {

    private object Keys {
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val CUSTOM_SOUND_URI = stringPreferencesKey("custom_sound_uri")
        fun prayerEnabled(prayer: PrayerKey) = booleanPreferencesKey("enabled_${prayer.name}")
    }

    val settingsFlow: Flow<AdhanSettings> = context.adhanDataStore.data.map { prefs ->
        AdhanSettings(
            enabledPrayers = PrayerKey.entries.filter { prefs[Keys.prayerEnabled(it)] != false }.toSet(),
            customSoundUri = prefs[Keys.CUSTOM_SOUND_URI],
            notificationsEnabled = prefs[Keys.NOTIFICATIONS_ENABLED] != false
        )
    }

    suspend fun currentSettings(): AdhanSettings = settingsFlow.first()

    suspend fun setPrayerEnabled(prayer: PrayerKey, enabled: Boolean) {
        context.adhanDataStore.edit { it[Keys.prayerEnabled(prayer)] = enabled }
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.adhanDataStore.edit { it[Keys.NOTIFICATIONS_ENABLED] = enabled }
    }

    suspend fun setCustomSoundUri(uri: String?) {
        context.adhanDataStore.edit {
            if (uri == null) it.remove(Keys.CUSTOM_SOUND_URI) else it[Keys.CUSTOM_SOUND_URI] = uri
        }
    }
}
