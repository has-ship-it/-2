package com.rashadmuslim.app.ui.screens.qibla

import android.Manifest
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.PermissionStatus
import com.google.accompanist.permissions.rememberPermissionState
import com.rashadmuslim.app.ui.components.ErrorState
import com.rashadmuslim.app.ui.components.LoadingState

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun QiblaScreen(viewModel: QiblaViewModel = viewModel()) {
    val locationPermission = rememberPermissionState(Manifest.permission.ACCESS_FINE_LOCATION)
    val state by viewModel.state.collectAsState()
    val heading by viewModel.heading.collectAsState()

    LaunchedEffect(locationPermission.status) {
        if (locationPermission.status == PermissionStatus.Granted) {
            viewModel.load()
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("اتجاه القبلة", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        if (locationPermission.status != PermissionStatus.Granted) {
            Column(
                Modifier.fillMaxSize().padding(padding).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("نحتاج إذن الموقع لحساب اتجاه القبلة بدقة", style = MaterialTheme.typography.bodyLarge)
                Button(modifier = Modifier.padding(top = 16.dp), onClick = { locationPermission.launchPermissionRequest() }) {
                    Text("منح الإذن")
                }
            }
        } else {
            when (val s = state) {
                is QiblaUiState.Loading -> LoadingState(Modifier.padding(padding))
                is QiblaUiState.Error -> ErrorState(s.message, onRetry = viewModel::load, modifier = Modifier.padding(padding))
                is QiblaUiState.Success -> Compass(s.qiblaBearing, heading, padding)
            }
        }
    }
}

@Composable
private fun Compass(qiblaBearing: Double, deviceHeading: Float, padding: PaddingValues) {
    // زاوية دوران السهم = اتجاه القبلة بالنسبة للشمال ناقص اتجاه الجهاز الحالي
    val arrowRotation = (qiblaBearing - deviceHeading).toFloat()

    Column(
        Modifier.fillMaxSize().padding(padding),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(240.dp), contentAlignment = Alignment.Center) {
            val primary = MaterialTheme.colorScheme.primary
            val outline = MaterialTheme.colorScheme.outline
            val gold = MaterialTheme.colorScheme.secondary

            Canvas(Modifier.size(240.dp)) {
                drawCircle(color = outline.copy(alpha = 0.25f), radius = size.minDimension / 2, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f))
                rotate(arrowRotation) {
                    val center = Offset(size.width / 2, size.height / 2)
                    val tip = Offset(size.width / 2, 14f)
                    drawLine(color = gold, start = center, end = tip, strokeWidth = 10f, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                    drawCircle(color = primary, radius = 16f, center = tip)
                }
                drawCircle(color = Color(0xFF1C2620), radius = 10f, center = Offset(size.width / 2, size.height / 2))
            }
        }
        Text(
            "وجّه الجهاز بشكل مسطح؛ السهم الذهبي يشير إلى الكعبة المشرّفة",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.outline,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.padding(top = 20.dp, start = 32.dp, end = 32.dp)
        )
    }
}
