package com.rashadmuslim.app.ui.screens.quran

import android.media.MediaPlayer
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rashadmuslim.app.data.model.SurahDetail
import com.rashadmuslim.app.data.model.surahAudioUrl
import com.rashadmuslim.app.ui.components.ErrorState
import com.rashadmuslim.app.ui.components.LoadingState

@Composable
fun SurahDetailScreen(
    onBack: () -> Unit,
    viewModel: SurahDetailViewModel = viewModel()
) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    val title = (state as? SurahDetailUiState.Success)?.surah?.name ?: "السورة"
                    Text(title, fontWeight = FontWeight.Bold)
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "رجوع") }
                }
            )
        }
    ) { padding ->
        when (val s = state) {
            is SurahDetailUiState.Loading -> LoadingState(Modifier.padding(padding))
            is SurahDetailUiState.Error -> ErrorState(s.message, onRetry = viewModel::load, modifier = Modifier.padding(padding))
            is SurahDetailUiState.Success -> SurahContent(s.surah, padding)
        }
    }
}

@Composable
private fun SurahContent(surah: SurahDetail, padding: PaddingValues) {
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(false) }

    // تحرير مشغّل الصوت عند مغادرة الشاشة لتفادي تسريب الذاكرة
    DisposableEffect(Unit) {
        onDispose { mediaPlayer?.release() }
    }

    Column(Modifier.fillMaxSize().padding(padding)) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(
                Modifier.fillMaxWidth().padding(16.dp),
                horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
            ) {
                val type = if (surah.revelationType == "Meccan") "مكية" else "مدنية"
                Text("$type · ${surah.numberOfAyahs} آية", style = MaterialTheme.typography.bodyMedium)
                FilledTonalIconButton(
                    modifier = Modifier.padding(top = 8.dp),
                    onClick = {
                        val player = mediaPlayer
                        if (player == null) {
                            val newPlayer = MediaPlayer().apply {
                                setDataSource(surahAudioUrl(surah.number))
                                setOnPreparedListener { it.start() }
                                setOnCompletionListener { isPlaying = false }
                                prepareAsync()
                            }
                            mediaPlayer = newPlayer
                            isPlaying = true
                        } else if (isPlaying) {
                            player.pause()
                            isPlaying = false
                        } else {
                            player.start()
                            isPlaying = true
                        }
                    }
                ) {
                    Icon(
                        if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = "استماع للسورة"
                    )
                }
            }
        }

        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            items(surah.ayahs, key = { it.number }) { ayah ->
                Text(
                    text = "${ayah.text} ﴿${ayah.numberInSurah}﴾",
                    style = MaterialTheme.typography.bodyLarge.copy(fontSize = 20.sp, lineHeight = 38.sp),
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
