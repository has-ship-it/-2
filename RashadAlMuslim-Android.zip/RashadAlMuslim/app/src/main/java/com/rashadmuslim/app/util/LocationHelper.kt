package com.rashadmuslim.app.util

import android.annotation.SuppressLint
import android.content.Context
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

data class LatLon(val latitude: Double, val longitude: Double)

/**
 * يطلب موقعًا واحدًا دقيقًا. يجب التأكد من منح إذن الموقع قبل استدعائها
 * (تُستخدم مع Accompanist Permissions في الشاشات).
 */
@SuppressLint("MissingPermission")
suspend fun getCurrentLocation(context: Context): LatLon? = suspendCancellableCoroutine { cont ->
    val client = LocationServices.getFusedLocationProviderClient(context)
    client.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, null)
        .addOnSuccessListener { location ->
            if (location != null) {
                cont.resume(LatLon(location.latitude, location.longitude))
            } else {
                cont.resume(null)
            }
        }
        .addOnFailureListener { cont.resume(null) }
}
