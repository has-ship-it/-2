package com.rashadmuslim.app.data.repository

import com.rashadmuslim.app.data.model.Surah
import com.rashadmuslim.app.data.model.SurahDetail
import com.rashadmuslim.app.network.NetworkModule

class QuranRepository(
    private val api: com.rashadmuslim.app.network.QuranApiService = NetworkModule.quranApi
) {
    suspend fun getSurahList(): Result<List<Surah>> = runCatching {
        api.getSurahList().data
    }

    suspend fun getSurah(number: Int): Result<SurahDetail> = runCatching {
        api.getSurah(number).data
    }
}
