package com.rashadmuslim.app.data.repository

import com.rashadmuslim.app.data.model.QiblaData
import com.rashadmuslim.app.data.model.TimingsData
import com.rashadmuslim.app.network.AladhanApiService
import com.rashadmuslim.app.network.NetworkModule

class PrayerRepository(
    private val api: AladhanApiService = NetworkModule.aladhanApi
) {
    suspend fun getTodayTimings(lat: Double, lon: Double): Result<TimingsData> = runCatching {
        api.getTimingsToday(lat, lon).data
    }

    suspend fun getQibla(lat: Double, lon: Double): Result<QiblaData> = runCatching {
        api.getQibla(lat, lon).data
    }
}
