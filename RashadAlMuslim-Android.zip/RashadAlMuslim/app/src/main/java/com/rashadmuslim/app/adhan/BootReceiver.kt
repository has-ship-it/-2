package com.rashadmuslim.app.adhan

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * المنبّهات الدقيقة (AlarmManager) تُلغى تلقائيًا عند إعادة إقلاع الجهاز، وقد تفقد دقتها
 * عند تغيير الوقت/المنطقة الزمنية يدويًا. هذا المستقبِل يعيد جدولة مواقيت اليوم في هذه الحالات.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AdhanScheduler.scheduleForToday(context.applicationContext)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
