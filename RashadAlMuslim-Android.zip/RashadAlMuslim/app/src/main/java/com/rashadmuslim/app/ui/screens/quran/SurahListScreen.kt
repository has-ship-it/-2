package com.rashadmuslim.app.ui.screens.quran

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rashadmuslim.app.data.model.Surah
import com.rashadmuslim.app.ui.components.ErrorState
import com.rashadmuslim.app.ui.components.LoadingState

@Composable
fun SurahListScreen(
    onSurahClick: (Int) -> Unit,
    viewModel: SurahListViewModel = viewModel()
) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text("القرآن الكريم", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        when (val s = state) {
            is SurahListUiState.Loading -> LoadingState(Modifier.padding(padding))
            is SurahListUiState.Error -> ErrorState(s.message, onRetry = viewModel::load, modifier = Modifier.padding(padding))
            is SurahListUiState.Success -> SurahList(s.surahs, padding, onSurahClick)
        }
    }
}

@Composable
private fun SurahList(surahs: List<Surah>, padding: PaddingValues, onSurahClick: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(padding)) {
        items(surahs, key = { it.number }) { surah ->
            SurahRow(surah, onClick = { onSurahClick(surah.number) })
            HorizontalDivider()
        }
    }
}

@Composable
private fun SurahRow(surah: Surah, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("${surah.number}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        }
        Column(Modifier.padding(start = 12.dp).weight(1f)) {
            Text(surah.name, style = MaterialTheme.typography.titleMedium)
            val type = if (surah.revelationType == "Meccan") "مكية" else "مدنية"
            Text("$type · ${surah.numberOfAyahs} آية", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.outline)
        }
    }
}
