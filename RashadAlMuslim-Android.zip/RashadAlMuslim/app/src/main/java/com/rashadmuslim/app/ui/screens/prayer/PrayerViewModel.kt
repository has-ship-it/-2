package com.rashadmuslim.app.ui.screens.prayer

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rashadmuslim.app.data.model.Timings
import com.rashadmuslim.app.data.model.toOrderedArabicList
import com.rashadmuslim.app.data.repository.PrayerRepository
import com.rashadmuslim.app.util.getCurrentLocation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed interface PrayerUiState {
    data object Loading : PrayerUiState
    data class Success(val timings: List<Pair<String, String>>, val hijriDate: String?) : PrayerUiState
    data class Error(val message: String) : PrayerUiState
}

// AndroidViewModel لأنها تحتاج Context لطلب الموقع عبر FusedLocationProviderClient
class PrayerViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = PrayerRepository()

    private val _state = MutableStateFlow<PrayerUiState>(PrayerUiState.Loading)
    val state: StateFlow<PrayerUiState> = _state

    fun load() {
        _state.value = PrayerUiState.Loading
        viewModelScope.launch {
            val location = getCurrentLocation(getApplication())
            if (location == null) {
                _state.value = PrayerUiState.Error("تعذّر تحديد الموقع. تأكد من تفعيل خدمة الموقع ومنح الإذن.")
                return@launch
            }
            repository.getTodayTimings(location.latitude, location.longitude)
                .onSuccess { data ->
                    _state.value = PrayerUiState.Success(
                        timings = data.timings.toOrderedArabicList(),
                        hijriDate = data.date.hijri?.let { "${it.date} ${it.month.ar} ${it.year}هـ" }
                    )
                }
                .onFailure { _state.value = PrayerUiState.Error(it.message ?: "خطأ غير معروف") }
        }
    }
}
