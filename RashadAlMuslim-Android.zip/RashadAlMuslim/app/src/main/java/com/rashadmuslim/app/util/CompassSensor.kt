package com.rashadmuslim.app.util

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * يبث اتجاه بوصلة الجهاز (درجة الأزيموث بالنسبة للشمال المغناطيسي) كتدفّق Flow،
 * باستخدام حساس TYPE_ROTATION_VECTOR المتوفر في أغلب أجهزة أندرويد الحديثة.
 */
fun compassFlow(context: Context): Flow<Float> = callbackFlow {
    val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

    if (rotationSensor == null) {
        close()
        return@callbackFlow
    }

    val rotationMatrix = FloatArray(9)
    val orientation = FloatArray(3)

    val listener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
            SensorManager.getOrientation(rotationMatrix, orientation)
            val azimuthRad = orientation[0]
            var azimuthDeg = Math.toDegrees(azimuthRad.toDouble()).toFloat()
            if (azimuthDeg < 0) azimuthDeg += 360f
            trySend(azimuthDeg)
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    }

    sensorManager.registerListener(listener, rotationSensor, SensorManager.SENSOR_DELAY_UI)

    awaitClose { sensorManager.unregisterListener(listener) }
}
