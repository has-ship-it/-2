package com.rashadmuslim.app.ui.screens.prayer

import android.Manifest
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.PermissionStatus
import com.google.accompanist.permissions.rememberPermissionState
import com.rashadmuslim.app.adhan.AdhanScheduler
import com.rashadmuslim.app.ui.components.ErrorState
import com.rashadmuslim.app.ui.components.LoadingState
import kotlinx.coroutines.launch

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun PrayerScreen(viewModel: PrayerViewModel = viewModel()) {
    val locationPermission = rememberPermissionState(Manifest.permission.ACCESS_FINE_LOCATION)
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    LaunchedEffect(locationPermission.status) {
        if (locationPermission.status == PermissionStatus.Granted) {
            viewModel.load()
            scope.launch { AdhanScheduler.scheduleForToday(context) }
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("مواقيت الصلاة", fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        if (locationPermission.status != PermissionStatus.Granted) {
            PermissionRequest(padding) { locationPermission.launchPermissionRequest() }
        } else {
            when (val s = state) {
                is PrayerUiState.Loading -> LoadingState(Modifier.padding(padding))
                is PrayerUiState.Error -> ErrorState(s.message, onRetry = viewModel::load, modifier = Modifier.padding(padding))
                is PrayerUiState.Success -> TimingsList(s, padding)
            }
        }
    }
}

@Composable
private fun PermissionRequest(padding: PaddingValues, onRequest: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(padding).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("نحتاج إذن الموقع لحساب مواقيت الصلاة في منطقتك", style = MaterialTheme.typography.bodyLarge)
        Button(modifier = Modifier.padding(top = 16.dp), onClick = onRequest) {
            Text("منح الإذن")
        }
    }
}

@Composable
private fun TimingsList(state: PrayerUiState.Success, padding: PaddingValues) {
    Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
        state.hijriDate?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.outline)
        }
        Card(
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.padding(4.dp)) {
                state.timings.forEachIndexed { index, (name, time) ->
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(name, style = MaterialTheme.typography.titleMedium)
                        Text(time, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    }
                    if (index != state.timings.lastIndex) HorizontalDivider()
                }
            }
        }
    }
}
