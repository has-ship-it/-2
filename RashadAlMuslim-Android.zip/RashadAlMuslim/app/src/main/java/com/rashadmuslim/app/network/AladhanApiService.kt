package com.rashadmuslim.app.network

import com.rashadmuslim.app.data.model.QiblaResponse
import com.rashadmuslim.app.data.model.TimingsResponse
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * واجهة مواقيت الصلاة واتجاه القبلة: مبنية على Aladhan API (مجانية وبلا مفتاح API).
 * التوثيق: https://aladhan.com/prayer-times-api و https://aladhan.com/qibla-api
 */
interface AladhanApiService {

    // method=4 هو "جامعة أم القرى، مكة المكرمة" — طريقة حساب افتراضية شائعة.
    // يمكن لاحقًا إضافة شاشة إعدادات لتغيير method حسب اختيار المستخدم.
    @GET("v1/timings")
    suspend fun getTimingsToday(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("method") method: Int = 4
    ): TimingsResponse

    @GET("v1/qibla/{latitude}/{longitude}")
    suspend fun getQibla(
        @Path("latitude") latitude: Double,
        @Path("longitude") longitude: Double
    ): QiblaResponse
}
