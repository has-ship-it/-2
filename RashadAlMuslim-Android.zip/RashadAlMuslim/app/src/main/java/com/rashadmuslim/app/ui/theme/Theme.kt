package com.rashadmuslim.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = GreenPrimary,
    onPrimary = Color.White,
    primaryContainer = GreenLight,
    onPrimaryContainer = GreenPrimary,
    secondary = GoldAccent,
    secondaryContainer = GoldSoft,
    background = Ivory,
    surface = Surface,
    onBackground = InkDay,
    onSurface = InkDay,
    outline = MutedDay,
)

private val DarkColors = darkColorScheme(
    primary = GreenPrimaryDark,
    onPrimary = Color.Black,
    primaryContainer = GreenLightDark,
    onPrimaryContainer = GreenPrimaryDark,
    secondary = GoldAccentDark,
    secondaryContainer = GreenLightDark,
    background = BgDark,
    surface = SurfaceDark,
    onBackground = InkNight,
    onSurface = InkNight,
    outline = MutedNight,
)

@Composable
fun RashadAlMuslimTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = ZadTypography,
        content = content
    )
}
