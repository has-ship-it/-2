package com.rashadmuslim.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.rashadmuslim.app.ui.navigation.RashadNavHost
import com.rashadmuslim.app.ui.theme.RashadAlMuslimTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // التطبيق عربي بالكامل، لذا نفرض اتجاه RTL بصرف النظر عن لغة النظام
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                RashadAlMuslimTheme {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        RashadNavHost()
                    }
                }
            }
        }
    }
}
