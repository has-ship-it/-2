package com.rashadmuslim.app.ui.theme

import androidx.compose.ui.graphics.Color

// وضع النهار
val GreenPrimary = Color(0xFF0E4A38)
val GreenLight = Color(0xFFE4EFE9)
val GoldAccent = Color(0xFFB5892B)
val GoldSoft = Color(0xFFF1E6C9)
val Ivory = Color(0xFFF6F4EC)
val Surface = Color(0xFFFFFFFF)
val InkDay = Color(0xFF1C2620)
val MutedDay = Color(0xFF6B7A70)

// الوضع الليلي
val GreenPrimaryDark = Color(0xFF5FBE96)
val GreenLightDark = Color(0xFF1B3229)
val GoldAccentDark = Color(0xFFD8B75B)
val BgDark = Color(0xFF0F1912)
val SurfaceDark = Color(0xFF152420)
val InkNight = Color(0xFFEDEFE9)
val MutedNight = Color(0xFF93A599)
