package com.rashadmuslim.app.adhan

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.rashadmuslim.app.MainActivity
import com.rashadmuslim.app.data.AdhanPreferencesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

private const val CHANNEL_ID = "adhan_channel"
private const val NOTIFICATION_ID = 1001

/**
 * خدمة أمامية قصيرة العمر: تُظهر إشعار "حان وقت الصلاة" وتشغّل الصوت المختار
 * (صوت مخصّص اختاره المستخدم، أو صوت الإشعار الافتراضي للنظام إن لم يختر شيئًا).
 * تتوقف تلقائيًا بعد انتهاء الصوت أو بعد حد أقصى زمني لتوفير البطارية.
 */
class AdhanService : Service() {

    private var mediaPlayer: MediaPlayer? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prayerName = intent?.getStringExtra(EXTRA_PRAYER_NAME) ?: "الصلاة"
        createChannelIfNeeded()
        startForeground(NOTIFICATION_ID, buildNotification(prayerName))
        playSound()

        // جدولة اليوم التالي فور انطلاق الأذان (يبقي الجدول محدّثًا يوميًا بلا تدخل المستخدم)
        scope.launch { AdhanScheduler.scheduleForToday(applicationContext) }

        return START_NOT_STICKY
    }

    private fun playSound() {
        scope.launch {
            val customUri = AdhanPreferencesRepository(applicationContext).currentSettings().customSoundUri
            try {
                val player = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    val soundUri = customUri?.let { Uri.parse(it) }
                        ?: android.provider.Settings.System.DEFAULT_NOTIFICATION_URI
                    setDataSource(applicationContext, soundUri)
                    setOnCompletionListener { stopSelfSafely() }
                    setOnErrorListener { _, _, _ -> stopSelfSafely(); true }
                    prepareAsync()
                    setOnPreparedListener { it.start() }
                }
                mediaPlayer = player

                // حد أقصى 90 ثانية احتياطًا في حال لم يُطلق حدث اكتمال التشغيل
                kotlinx.coroutines.delay(90_000)
                stopSelfSafely()
            } catch (e: Exception) {
                stopSelfSafely()
            }
        }
    }

    private fun stopSelfSafely() {
        mediaPlayer?.release()
        mediaPlayer = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(prayerName: String): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(com.rashadmuslim.app.R.drawable.ic_stat_adhan)
            .setContentTitle("حان الآن وقت صلاة $prayerName")
            .setContentText("اضغط لفتح رشاد المسلم")
            .setContentIntent(openAppIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .build()
    }

    private fun createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            if (manager.getNotificationChannel(CHANNEL_ID) == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID, "تنبيهات الأذان", NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "إشعارات مواقيت الصلاة الخمس"
                    // الصوت يُشغَّل يدويًا عبر MediaPlayer أعلاه (وليس عبر القناة) للسماح
                    // بإيقافه تلقائيًا بعد مدة محددة والتحكم بالصوت المخصص.
                    setSound(null, null)
                }
                manager.createNotificationChannel(channel)
            }
        }
    }

    override fun onDestroy() {
        mediaPlayer?.release()
        mediaPlayer = null
        super.onDestroy()
    }
}
