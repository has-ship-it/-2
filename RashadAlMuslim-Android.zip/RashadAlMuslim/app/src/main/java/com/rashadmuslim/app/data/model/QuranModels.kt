package com.rashadmuslim.app.data.model

data class SurahListResponse(
    val code: Int,
    val status: String,
    val data: List<Surah>
)

data class SurahDetailResponse(
    val code: Int,
    val status: String,
    val data: SurahDetail
)

data class Surah(
    val number: Int,
    val name: String,              // الاسم بالعربية، مثل "سورة الملك"
    val englishName: String,
    val englishNameTranslation: String,
    val numberOfAyahs: Int,
    val revelationType: String     // "Meccan" أو "Medinan"
)

data class SurahDetail(
    val number: Int,
    val name: String,
    val englishName: String,
    val revelationType: String,
    val numberOfAyahs: Int,
    val ayahs: List<Ayah>
)

data class Ayah(
    val number: Int,       // رقم الآية المطلق في المصحف كاملًا
    val text: String,      // نص الآية بالرسم العثماني
    val numberInSurah: Int,
    val juz: Int,
    val page: Int
)

/** رابط صوت السورة كاملة من شبكة Islamic Network CDN (بدون الحاجة لواجهة برمجية إضافية). */
fun surahAudioUrl(surahNumber: Int, edition: String = "ar.alafasy", bitrateKbps: Int = 128): String =
    "https://cdn.islamic.network/quran/audio-surah/$bitrateKbps/$edition/$surahNumber.mp3"
