package com.rashadmuslim.app.ui.screens.quran

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rashadmuslim.app.data.model.SurahDetail
import com.rashadmuslim.app.data.repository.QuranRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed interface SurahDetailUiState {
    data object Loading : SurahDetailUiState
    data class Success(val surah: SurahDetail) : SurahDetailUiState
    data class Error(val message: String) : SurahDetailUiState
}

class SurahDetailViewModel(
    private val savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val repository = QuranRepository()
    private val surahNumber: Int = checkNotNull(savedStateHandle["surahNumber"])

    private val _state = MutableStateFlow<SurahDetailUiState>(SurahDetailUiState.Loading)
    val state: StateFlow<SurahDetailUiState> = _state

    init { load() }

    fun load() {
        _state.value = SurahDetailUiState.Loading
        viewModelScope.launch {
            repository.getSurah(surahNumber)
                .onSuccess { _state.value = SurahDetailUiState.Success(it) }
                .onFailure { _state.value = SurahDetailUiState.Error(it.message ?: "خطأ غير معروف") }
        }
    }
}
