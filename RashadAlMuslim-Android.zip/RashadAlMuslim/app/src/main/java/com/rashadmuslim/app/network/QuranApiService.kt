package com.rashadmuslim.app.network

import com.rashadmuslim.app.data.model.SurahDetailResponse
import com.rashadmuslim.app.data.model.SurahListResponse
import retrofit2.http.GET
import retrofit2.http.Path

/**
 * واجهة القرآن الكريم: مبنية على AlQuran Cloud API (مجانية وبلا مفتاح API).
 * التوثيق: https://alquran.cloud/api
 */
interface QuranApiService {

    @GET("v1/surah")
    suspend fun getSurahList(): SurahListResponse

    // edition = "quran-uthmani" يعطي النص العربي بالرسم العثماني
    @GET("v1/surah/{number}/{edition}")
    suspend fun getSurah(
        @Path("number") number: Int,
        @Path("edition") edition: String = "quran-uthmani"
    ): SurahDetailResponse
}
