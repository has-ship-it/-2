package com.rashadmuslim.app.data.model

data class TimingsResponse(
    val code: Int,
    val status: String,
    val data: TimingsData
)

data class TimingsData(
    val timings: Timings,
    val date: DateInfo
)

// الأوقات تأتي كنص "HH:mm" (وقد تحتوي أحيانًا على منطقة زمنية، لذا تُقص لاحقًا عند العرض)
data class Timings(
    val Fajr: String,
    val Sunrise: String,
    val Dhuhr: String,
    val Asr: String,
    val Maghrib: String,
    val Isha: String
)

data class DateInfo(
    val readable: String,
    val hijri: HijriDate?
)

data class HijriDate(
    val date: String,
    val month: HijriMonth,
    val year: String
)

data class HijriMonth(
    val ar: String
)

data class QiblaResponse(
    val code: Int,
    val status: String,
    val data: QiblaData
)

data class QiblaData(
    val latitude: Double,
    val longitude: Double,
    val direction: Double  // درجة الاتجاه نحو الكعبة (بالنسبة للشمال الجغرافي)، بالساعة دورانًا
)

/** يحوّل خريطة الأوقات الخام إلى قائمة مرتبة بأسمائها العربية لعرضها في الواجهة. */
fun Timings.toOrderedArabicList(): List<Pair<String, String>> = listOf(
    "الفجر" to Fajr.take(5),
    "الشروق" to Sunrise.take(5),
    "الظهر" to Dhuhr.take(5),
    "العصر" to Asr.take(5),
    "المغرب" to Maghrib.take(5),
    "العشاء" to Isha.take(5),
)
