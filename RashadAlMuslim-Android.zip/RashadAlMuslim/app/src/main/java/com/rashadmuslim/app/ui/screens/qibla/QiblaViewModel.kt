package com.rashadmuslim.app.ui.screens.qibla

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rashadmuslim.app.data.repository.PrayerRepository
import com.rashadmuslim.app.util.compassFlow
import com.rashadmuslim.app.util.getCurrentLocation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed interface QiblaUiState {
    data object Loading : QiblaUiState
    data class Success(val qiblaBearing: Double) : QiblaUiState
    data class Error(val message: String) : QiblaUiState
}

class QiblaViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = PrayerRepository()

    private val _state = MutableStateFlow<QiblaUiState>(QiblaUiState.Loading)
    val state: StateFlow<QiblaUiState> = _state

    private val _heading = MutableStateFlow(0f)
    val heading: StateFlow<Float> = _heading

    fun load() {
        _state.value = QiblaUiState.Loading
        viewModelScope.launch {
            val location = getCurrentLocation(getApplication())
            if (location == null) {
                _state.value = QiblaUiState.Error("تعذّر تحديد الموقع. تأكد من تفعيل خدمة الموقع ومنح الإذن.")
                return@launch
            }
            repository.getQibla(location.latitude, location.longitude)
                .onSuccess { _state.value = QiblaUiState.Success(it.direction) }
                .onFailure { _state.value = QiblaUiState.Error(it.message ?: "خطأ غير معروف") }
        }
        viewModelScope.launch {
            compassFlow(getApplication()).collect { _heading.value = it }
        }
    }
}
