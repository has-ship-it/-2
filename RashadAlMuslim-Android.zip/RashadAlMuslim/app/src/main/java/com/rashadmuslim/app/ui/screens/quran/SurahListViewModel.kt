package com.rashadmuslim.app.ui.screens.quran

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rashadmuslim.app.data.model.Surah
import com.rashadmuslim.app.data.repository.QuranRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed interface SurahListUiState {
    data object Loading : SurahListUiState
    data class Success(val surahs: List<Surah>) : SurahListUiState
    data class Error(val message: String) : SurahListUiState
}

class SurahListViewModel : ViewModel() {
    private val repository = QuranRepository()

    private val _state = MutableStateFlow<SurahListUiState>(SurahListUiState.Loading)
    val state: StateFlow<SurahListUiState> = _state

    init { load() }

    fun load() {
        _state.value = SurahListUiState.Loading
        viewModelScope.launch {
            repository.getSurahList()
                .onSuccess { _state.value = SurahListUiState.Success(it) }
                .onFailure { _state.value = SurahListUiState.Error(it.message ?: "خطأ غير معروف") }
        }
    }
}
