package com.rashadmuslim.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.rashadmuslim.app.ui.screens.prayer.PrayerScreen
import com.rashadmuslim.app.ui.screens.qibla.QiblaScreen
import com.rashadmuslim.app.ui.screens.quran.SurahDetailScreen
import com.rashadmuslim.app.ui.screens.quran.SurahListScreen

private sealed class Tab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    data object Quran : Tab("quran_list", "القرآن", Icons.Filled.MenuBook)
    data object Prayer : Tab("prayer", "الصلاة", Icons.Filled.Mosque)
    data object Qibla : Tab("qibla", "القبلة", Icons.Filled.Explore)
}

private val tabs = listOf(Tab.Quran, Tab.Prayer, Tab.Qibla)

@Composable
fun RashadNavHost() {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = { ZadBottomBar(navController) }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Tab.Quran.route,
            modifier = androidx.compose.ui.Modifier.padding(padding)
        ) {
            composable(Tab.Quran.route) {
                SurahListScreen(onSurahClick = { number ->
                    navController.navigate("surah_detail/$number")
                })
            }
            composable(
                route = "surah_detail/{surahNumber}",
                arguments = listOf(navArgument("surahNumber") { type = androidx.navigation.NavType.IntType })
            ) {
                SurahDetailScreen(onBack = { navController.popBackStack() })
            }
            composable(Tab.Prayer.route) { PrayerScreen() }
            composable(Tab.Qibla.route) { QiblaScreen() }
        }
    }
}

@Composable
private fun ZadBottomBar(navController: NavHostController) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination

    NavigationBar {
        tabs.forEach { tab ->
            val selected = currentRoute?.hierarchy?.any { it.route == tab.route } == true
            NavigationBarItem(
                selected = selected,
                onClick = {
                    navController.navigate(tab.route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = { Icon(tab.icon, contentDescription = tab.label) },
                label = { Text(tab.label) }
            )
        }
    }
}
