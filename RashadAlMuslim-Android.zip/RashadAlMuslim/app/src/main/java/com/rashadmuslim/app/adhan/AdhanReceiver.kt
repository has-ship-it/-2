package com.rashadmuslim.app.adhan

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/**
 * يُستدعى تلقائيًا من AlarmManager عند حلول وقت صلاة مفعّلة.
 * يبدأ خدمة أمامية (Foreground Service) تعرض الإشعار وتشغّل الصوت.
 */
class AdhanReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val serviceIntent = Intent(context, AdhanService::class.java).apply {
            putExtra(EXTRA_PRAYER_NAME, intent.getStringExtra(EXTRA_PRAYER_NAME))
            putExtra(EXTRA_PRAYER_KEY, intent.getStringExtra(EXTRA_PRAYER_KEY))
        }
        ContextCompat.startForegroundService(context, serviceIntent)
    }
}
