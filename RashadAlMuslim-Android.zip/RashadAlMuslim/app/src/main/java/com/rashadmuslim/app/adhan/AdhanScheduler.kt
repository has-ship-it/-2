package com.rashadmuslim.app.adhan

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import com.rashadmuslim.app.data.AdhanPreferencesRepository
import com.rashadmuslim.app.data.PrayerKey
import com.rashadmuslim.app.data.repository.PrayerRepository
import com.rashadmuslim.app.util.getCurrentLocation
import java.util.Calendar

const val EXTRA_PRAYER_NAME = "prayer_name_ar"
const val EXTRA_PRAYER_KEY = "prayer_key"

/**
 * يجلب مواقيت اليوم حسب الموقع الحالي، ثم يضبط منبّهًا دقيقًا (Exact Alarm) لكل صلاة
 * مفعّلة لدى المستخدم ولم يَفُت وقتها بعد. يُستدعى عند فتح التطبيق، وبعد كل أذان
 * (لضبط اليوم التالي)، وعند الإقلاع/تغيّر الوقت عبر BootReceiver.
 */
object AdhanScheduler {

    private const val TAG = "AdhanScheduler"

    private val arabicNames = mapOf(
        PrayerKey.Fajr to "الفجر",
        PrayerKey.Dhuhr to "الظهر",
        PrayerKey.Asr to "العصر",
        PrayerKey.Maghrib to "المغرب",
        PrayerKey.Isha to "العشاء",
    )

    suspend fun scheduleForToday(context: Context) {
        val prefsRepo = AdhanPreferencesRepository(context)
        val settings = prefsRepo.currentSettings()
        if (!settings.notificationsEnabled || settings.enabledPrayers.isEmpty()) {
            Log.i(TAG, "الإشعارات معطّلة أو لا توجد صلوات مفعّلة — تم تخطي الجدولة")
            return
        }

        val location = getCurrentLocation(context) ?: run {
            Log.w(TAG, "تعذّر تحديد الموقع لجدولة الأذان")
            return
        }

        val result = PrayerRepository().getTodayTimings(location.latitude, location.longitude)
        val timings = result.getOrNull()?.timings ?: run {
            Log.w(TAG, "تعذّر جلب مواقيت اليوم لجدولة الأذان")
            return
        }

        val raw = mapOf(
            PrayerKey.Fajr to timings.Fajr,
            PrayerKey.Dhuhr to timings.Dhuhr,
            PrayerKey.Asr to timings.Asr,
            PrayerKey.Maghrib to timings.Maghrib,
            PrayerKey.Isha to timings.Isha,
        )

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = Calendar.getInstance()

        for (prayer in settings.enabledPrayers) {
            val hhmm = raw[prayer]?.take(5) ?: continue
            val parts = hhmm.split(":")
            val hour = parts.getOrNull(0)?.toIntOrNull() ?: continue
            val minute = parts.getOrNull(1)?.toIntOrNull() ?: continue

            val triggerAt = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
            }
            if (triggerAt.before(now)) continue // الوقت فات بالفعل اليوم

            val intent = Intent(context, AdhanReceiver::class.java).apply {
                putExtra(EXTRA_PRAYER_NAME, arabicNames[prayer])
                putExtra(EXTRA_PRAYER_KEY, prayer.name)
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                prayer.ordinal,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val canScheduleExact = android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.S ||
                alarmManager.canScheduleExactAlarms()

            if (canScheduleExact) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAt.timeInMillis,
                    pendingIntent
                )
            } else {
                // بلا إذن "المنبّهات الدقيقة" (Android 12+): ننبّه بدقة تقريبية بدل تجاهل الأذان كليًا
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt.timeInMillis, pendingIntent)
            }
        }
    }
}
